document.write('<script type="text/javascript" src="js/jquery.js"></script>');
document.write('<script type="text/javascript" src="js/index_header_js.js"></script>');
document.write('<script type="text/javascript" src="js/curvycorners.src.js"></script>');
document.write('<script type="text/javascript" src="js/lightbox_popup.js"></script>');

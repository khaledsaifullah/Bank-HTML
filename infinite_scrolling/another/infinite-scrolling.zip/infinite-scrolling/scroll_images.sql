-- phpMyAdmin SQL Dump
-- version 3.3.2deb1ubuntu1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 02, 2012 at 08:55 PM
-- Server version: 5.1.62
-- PHP Version: 5.3.2-1ubuntu4.15

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;



-- --------------------------------------------------------

--
-- Table structure for table `scroll_images`
--

CREATE TABLE IF NOT EXISTS `scroll_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `scroll_images`
--

INSERT INTO `scroll_images` (`id`, `name`, `order`) VALUES
(1, 'dhfc', 0),
(2, 'hqkw', 0),
(3, 'btsx', 0),
(4, 'pnyp', 0),
(5, 'tlqx', 0),
(6, 'pljh', 0),
(7, 'ncme', 0),
(8, 'viqj', 0),
(9, 'jniu', 0),
(10, 'vavc', 0),
(11, 'cftq', 0),
(12, 'mubg', 0),
(13, 'ojtk', 0),
(14, 'vmij', 0),
(15, 'csns', 0),
(16, 'qqoj', 0),
(17, 'iowr', 0),
(18, 'jftr', 0),
(19, 'lgyi', 0),
(20, 'qstq', 0),
(21, 'pmkl', 0),
(22, 'txwh', 0),
(23, 'fgim', 0),
(24, 'epet', 0),
(25, 'rebm', 0),
(26, 'ylpq', 0),
(27, 'buwu', 0),
(28, 'ppjh', 0),
(29, 'rusc', 0),
(30, 'xinf', 0),
(31, 'whhu', 0),
(32, 'nglh', 0),
(33, 'uwsx', 0),
(34, 'lljk', 0),
(35, 'zltx', 0),
(36, 'wqea', 0),
(37, 'nkrz', 0),
(38, 'idyb', 0),
(39, 'oohs', 0),
(40, 'stiv', 0),
(41, 'elib', 0),
(42, 'bqea', 0),
(43, 'fsmh', 0),
(44, 'vulj', 0),
(45, 'wxmc', 0),
(46, 'upxa', 0),
(47, 'mtns', 0),
(48, 'muqk', 0),
(49, 'xiql', 0),
(50, 'osnv', 0),
(51, 'ejmf', 0),
(52, 'fpli', 0),
(53, 'hbpk', 0),
(54, 'tbgx', 0),
(55, 'utqs', 0),
(56, 'mvkg', 0),
(57, 'scfv', 0),
(58, 'wosa', 0),
(59, 'zewq', 0),
(60, 'cnal', 0),
(61, 'eelz', 0),
(62, 'qwwt', 0),
(63, 'jbag', 0),
(64, 'kxxa', 0),
(65, 'vyor', 0),
(66, 'wqwr', 0),
(67, 'syjk', 0),
(68, 'mqvi', 0),
(69, 'losr', 0),
(70, 'eyzn', 0),
(71, 'zjli', 0),
(72, 'edim', 0),
(73, 'hghl', 0),
(74, 'glhb', 0),
(75, 'nmwx', 0),
(76, 'elre', 0),
(77, 'ysed', 0),
(78, 'mvmn', 0),
(79, 'zslj', 0),
(80, 'vaor', 0),
(81, 'dsxu', 0),
(82, 'ulpf', 0),
(83, 'blrl', 0),
(84, 'yagy', 0),
(85, 'dskv', 0),
(86, 'erep', 0),
(87, 'dfbt', 0),
(88, 'oewa', 0),
(89, 'kdct', 0),
(90, 'zcpr', 0),
(91, 'mhqb', 0),
(92, 'kwgy', 0),
(93, 'uywr', 0),
(94, 'ocil', 0),
(95, 'howd', 0),
(96, 'ysnq', 0),
(97, 'jdvo', 0),
(98, 'zule', 0),
(99, 'zurq', 0),
(100, 'sbmx', 0),
(101, 'yael', 0),
(102, 'qasv', 0);

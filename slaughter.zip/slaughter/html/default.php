<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

exit();


modMainMenuHelper::render($params, 'modMainMenuXMLCallback');
